# AhSell Auto Sell Mod

Fabric мод для Minecraft 1.21.x, который автоматически продаёт предметы через команду `/ah sell 40000`.

## Что делает мод

1. Нажимаешь **H** — мод включается
2. Автоматически отправляет `/ah sell 40000` для текущего предмета в руке
3. Через 0.5 сек переключается на следующий непустой слот хотбара
4. Когда хотбар заканчивается — автоматически берёт следующий предмет из инвентаря
5. Когда инвентарь полностью пуст — останавливается и пишет сообщение
6. Повторное нажатие **H** — выключает мод

## Как собрать мод

### Требования
- Java 21 (JDK)
- Git (опционально)

### Сборка

```bash
# Скачать Gradle Wrapper
./gradlew wrapper --gradle-version=8.8

# Собрать мод
./gradlew build
```

На Windows:
```cmd
gradlew.bat build
```

Готовый `.jar` файл будет в папке `build/libs/ahsell-mod-1.0.0.jar`

Скопируй его в папку `.minecraft/mods/`

## Настройка

В файле `AhSellMod.java` можно изменить:

```java
private static final String SELL_COMMAND = "/ah sell 40000"; // цена продажи
private static final int DELAY_TICKS = 40;      // 40 тиков = 2 сек между командами
private static final int MOVE_DELAY_TICKS = 10; // 10 тиков = 0.5 сек перед сменой слота
```

- **40000** — замени на нужную цену
- **DELAY_TICKS** — задержка перед каждой командой (если сервер не успевает — увеличь)
- **MOVE_DELAY_TICKS** — задержка после команды перед сменой слота

## Клавиша

По умолчанию: **H**

Можно сменить в настройках Minecraft → Управление → AhSell Мод

## Зависимости (уже указаны в build.gradle)

- Minecraft 1.21.1
- Fabric Loader 0.16.5+
- Fabric API 0.106.1+

## Структура проекта

```
ahsell-mod/
├── src/main/java/com/ahsell/mod/
│   └── AhSellMod.java          ← основная логика
├── src/main/resources/
│   ├── fabric.mod.json         ← метаданные мода
│   └── assets/ahsell/lang/
│       ├── ru_ru.json          ← названия клавиш (русский)
│       └── en_us.json          ← названия клавиш (английский)
├── build.gradle
├── settings.gradle
└── gradle.properties
```
