package com.ahsell.mod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class AhSellScreen extends Screen {

    private final AhSellConfig config;
    private final Screen parent;

    private TextFieldWidget priceField;
    private TextFieldWidget commandField;
    private TextFieldWidget delayField;
    private TextFieldWidget moveDelayField;

    private String errorMessage = "";

    public AhSellScreen(Screen parent, AhSellConfig config) {
        super(Text.literal("AhSell — Настройки"));
        this.parent = parent;
        this.config = config;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int fieldW = 200;
        int fieldH = 20;
        int labelGap = 12;
        int blockGap = 38;
        int startY = 45;

        // ── ЦЕНА ──
        priceField = new TextFieldWidget(textRenderer,
                cx - fieldW / 2, startY + labelGap,
                fieldW, fieldH, Text.literal("Цена"));
        priceField.setMaxLength(20);
        priceField.setText(String.valueOf(config.sellPrice));
        // Только цифры
        priceField.setTextPredicate(s -> s.isEmpty() || s.matches("\\d*"));
        addDrawableChild(priceField);

        // Быстрые пресеты цены
        int[] presets = {1000, 5000, 10000, 50000, 100000, 500000};
        String[] labels = {"1K", "5K", "10K", "50K", "100K", "500K"};
        int btnW = 36;
        int totalW = presets.length * btnW + (presets.length - 1) * 2;
        int btnStartX = cx - totalW / 2;
        for (int i = 0; i < presets.length; i++) {
            final int price = presets[i];
            addDrawableChild(ButtonWidget.builder(Text.literal(labels[i]), btn -> {
                priceField.setText(String.valueOf(price));
            }).dimensions(btnStartX + i * (btnW + 2), startY + labelGap + fieldH + 3, btnW, 14).build());
        }

        // ── КОМАНДА ──
        commandField = new TextFieldWidget(textRenderer,
                cx - fieldW / 2, startY + blockGap + labelGap + 16,
                fieldW, fieldH, Text.literal("Команда"));
        commandField.setMaxLength(64);
        commandField.setText(config.command);
        addDrawableChild(commandField);

        // ── ЗАДЕРЖКА КОМАНДЫ ──
        delayField = new TextFieldWidget(textRenderer,
                cx - fieldW / 2, startY + blockGap * 2 + labelGap + 16,
                90, fieldH, Text.literal("Задержка"));
        delayField.setMaxLength(5);
        delayField.setText(String.valueOf(config.delayTicks));
        delayField.setTextPredicate(s -> s.isEmpty() || s.matches("\\d*"));
        addDrawableChild(delayField);

        // ── ЗАДЕРЖКА СЛОТА ──
        moveDelayField = new TextFieldWidget(textRenderer,
                cx + 10, startY + blockGap * 2 + labelGap + 16,
                90, fieldH, Text.literal("Задержка слота"));
        moveDelayField.setMaxLength(5);
        moveDelayField.setText(String.valueOf(config.moveDelayTicks));
        moveDelayField.setTextPredicate(s -> s.isEmpty() || s.matches("\\d*"));
        addDrawableChild(moveDelayField);

        // ── КНОПКИ ──
        addDrawableChild(ButtonWidget.builder(Text.literal("§aSохранить"), btn -> save())
                .dimensions(cx - 105, this.height - 28, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("§cОтмена"), btn -> close())
                .dimensions(cx + 5, this.height - 28, 100, 20).build());
    }

    private void save() {
        errorMessage = "";
        boolean ok = true;

        // Цена
        try {
            String txt = priceField.getText().trim();
            if (txt.isEmpty()) throw new NumberFormatException();
            long price = Long.parseLong(txt);
            if (price <= 0) throw new NumberFormatException();
            config.sellPrice = price;
        } catch (NumberFormatException e) {
            errorMessage = "§cОшибка: введите корректную цену (число > 0)";
            ok = false;
        }

        // Команда
        String cmd = commandField.getText().trim();
        if (cmd.isEmpty()) {
            errorMessage = "§cОшибка: команда не может быть пустой";
            ok = false;
        } else {
            config.command = cmd.startsWith("/") ? cmd.substring(1) : cmd;
        }

        // Задержки
        try {
            int d = Integer.parseInt(delayField.getText().trim());
            config.delayTicks = Math.max(1, d);
        } catch (NumberFormatException e) {
            config.delayTicks = 40;
            delayField.setText("40");
        }
        try {
            int d = Integer.parseInt(moveDelayField.getText().trim());
            config.moveDelayTicks = Math.max(1, d);
        } catch (NumberFormatException e) {
            config.moveDelayTicks = 10;
            moveDelayField.setText("10");
        }

        if (ok) {
            config.save();
            close();
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);

        int cx = this.width / 2;
        int blockGap = 38;
        int startY = 45;

        // Заголовок
        ctx.drawCenteredTextWithShadow(textRenderer, "§6§lAhSell — Настройки", cx, 12, 0xFFFFFF);

        // Подписи
        ctx.drawTextWithShadow(textRenderer, "§eЦена продажи:", cx - 100, startY, 0xFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "§eКоманда §7(без / и цены):", cx - 100, startY + blockGap + 16, 0xFFFFFF);

        // Задержки — рядом
        int delayY = startY + blockGap * 2 + 16;
        ctx.drawTextWithShadow(textRenderer, "§eЗадержка команды §7(тики):", cx - 100, delayY, 0xFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "§eСмены слота §7(тики):", cx + 10, delayY, 0xFFFFFF);

        // Подсказка тиков
        ctx.drawCenteredTextWithShadow(textRenderer, "§720 тиков = 1 секунда", cx, delayY + 24, 0x888888);

        // Превью команды
        String pricePreview = priceField != null ? priceField.getText() : "?";
        String cmdPreview = commandField != null ? commandField.getText() : "?";
        ctx.drawCenteredTextWithShadow(textRenderer,
                "§7Итог: §f/" + cmdPreview + " " + pricePreview,
                cx, this.height - 48, 0xAAAAAA);

        // Ошибка
        if (!errorMessage.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, errorMessage, cx, this.height - 60, 0xFF5555);
        }

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() { return false; }
}
