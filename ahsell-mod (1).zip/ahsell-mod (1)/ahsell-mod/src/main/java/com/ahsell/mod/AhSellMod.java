package com.ahsell.mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AhSellMod implements ModInitializer {

    public static final String MOD_ID = "ahsell";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static AhSellConfig config;

    private static KeyBinding toggleKey;
    private static KeyBinding settingsKey;

    private boolean isRunning = false;
    private int tickCounter = 0;
    private int phase = 0;

    @Override
    public void onInitialize() {
        config = AhSellConfig.load();

        // H — вкл/выкл
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ahsell.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_H,
                "category.ahsell"
        ));

        // G — открыть настройки
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ahsell.settings",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "category.ahsell"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
        LOGGER.info("AhSell Mod загружен! H = вкл/выкл | G = настройки");
    }

    private void onClientTick(MinecraftClient client) {
        if (client.player == null || client.world == null) return;

        // Открыть настройки
        while (settingsKey.wasPressed()) {
            if (client.currentScreen == null) {
                client.setScreen(new AhSellScreen(null, config));
            }
        }

        // Вкл/выкл
        while (toggleKey.wasPressed()) {
            if (client.currentScreen != null) continue; // не переключать если открыто меню
            isRunning = !isRunning;
            tickCounter = 0;
            phase = 0;

            if (isRunning) {
                client.player.sendMessage(
                        Text.literal("§a[AhSell] §fАвтопродажа §aВКЛЮЧЕНА §7(цена: §e" + config.sellPrice + "§7) §f— H для отключения"),
                        false
                );
            } else {
                client.player.sendMessage(
                        Text.literal("§c[AhSell] §fАвтопродажа §cОТКЛЮЧЕНА"),
                        false
                );
            }
        }

        if (!isRunning) return;

        tickCounter++;

        // Фаза 0: отправить команду
        if (phase == 0 && tickCounter >= config.delayTicks) {
            ItemStack currentItem = client.player.getInventory().getStack(
                    client.player.getInventory().selectedSlot
            );

            if (currentItem.isEmpty()) {
                if (!refillHotbarFromInventory(client)) {
                    isRunning = false;
                    client.player.sendMessage(
                            Text.literal("§c[AhSell] §fИнвентарь пуст! Автопродажа остановлена."),
                            false
                    );
                    return;
                }
            }

            String fullCommand = config.command + " " + config.sellPrice;
            client.player.networkHandler.sendChatCommand(fullCommand);
            phase = 1;
            tickCounter = 0;
        }

        // Фаза 1: сменить слот
        if (phase == 1 && tickCounter >= config.moveDelayTicks) {
            moveToNextSlot(client);
            phase = 0;
            tickCounter = 0;
        }
    }

    private void moveToNextSlot(MinecraftClient client) {
        int currentSlot = client.player.getInventory().selectedSlot;

        for (int i = 1; i <= 9; i++) {
            int nextSlot = (currentSlot + i) % 9;
            ItemStack stack = client.player.getInventory().getStack(nextSlot);

            if (!stack.isEmpty()) {
                client.player.getInventory().selectedSlot = nextSlot;
                client.player.sendMessage(
                        Text.literal("§e[AhSell] §fСлот " + (nextSlot + 1) + ": §7" + stack.getName().getString()),
                        true
                );
                return;
            }
        }

        if (!refillHotbarFromInventory(client)) {
            isRunning = false;
            client.player.sendMessage(
                    Text.literal("§c[AhSell] §fВсе предметы проданы! Автопродажа остановлена."),
                    false
            );
        }
    }

    private boolean refillHotbarFromInventory(MinecraftClient client) {
        for (int invSlot = 9; invSlot <= 35; invSlot++) {
            ItemStack stack = client.player.getInventory().getStack(invSlot);
            if (!stack.isEmpty()) {
                client.player.getInventory().swapSlotWithHotbar(invSlot);
                client.player.sendMessage(
                        Text.literal("§b[AhSell] §fПополнение из инвентаря: §7" + stack.getName().getString()),
                        false
                );
                return true;
            }
        }
        return false;
    }
}
