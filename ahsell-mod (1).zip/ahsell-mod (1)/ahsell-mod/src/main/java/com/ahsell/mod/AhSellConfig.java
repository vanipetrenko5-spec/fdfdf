package com.ahsell.mod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Path;

public class AhSellConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("ahsell.json");

    // Настройки с дефолтными значениями
    public long sellPrice = 40000;
    public int delayTicks = 40;       // задержка между командами
    public int moveDelayTicks = 10;   // задержка перед сменой слота
    public String command = "ah sell"; // команда без / и без цены

    public static AhSellConfig load() {
        if (CONFIG_PATH.toFile().exists()) {
            try (Reader reader = new FileReader(CONFIG_PATH.toFile())) {
                return GSON.fromJson(reader, AhSellConfig.class);
            } catch (Exception e) {
                AhSellMod.LOGGER.error("Ошибка загрузки конфига, используем дефолтные значения", e);
            }
        }
        AhSellConfig config = new AhSellConfig();
        config.save();
        return config;
    }

    public void save() {
        try (Writer writer = new FileWriter(CONFIG_PATH.toFile())) {
            GSON.toJson(this, writer);
        } catch (Exception e) {
            AhSellMod.LOGGER.error("Ошибка сохранения конфига", e);
        }
    }
}
